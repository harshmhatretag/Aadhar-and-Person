package com.hib.project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/fetch")
public class FetchAllDataToJSP extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/Hib-Project1","root","harsh");
			
			String querry1= "select * from person";
			PreparedStatement ps1= con.prepareStatement(querry1);
			
			ResultSet rs1= ps1.executeQuery(querry1);
			req.setAttribute("data1", rs1);
			
			//============================================
			
			String querry2= "select * from aadhar";
			PreparedStatement ps2= con.prepareStatement(querry2);
			
			ResultSet rs2= ps2.executeQuery(querry2);
			req.setAttribute("data2", rs2);
			
			
			RequestDispatcher dis= req.getRequestDispatcher("display.jsp");
			dis.forward(req, resp);
			
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
