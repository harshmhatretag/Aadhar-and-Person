package com.hib.project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DeleteData {
	
	public static void main(String[] args) {

		EntityManagerFactory emf= Persistence.createEntityManagerFactory("harsh");
		EntityManager em= emf.createEntityManager();
		EntityTransaction et= em.getTransaction();
		
		Aadhar a1= em.find(Aadhar.class, 2);
		Person p1= em.find(Person.class, 2);
	
		et.begin();
		
		em.remove(a1);
		em.remove(p1);
		
		et.commit();
		
	}
	
}
