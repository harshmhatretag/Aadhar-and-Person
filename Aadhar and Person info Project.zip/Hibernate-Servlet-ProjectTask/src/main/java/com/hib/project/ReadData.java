package com.hib.project;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/readdata")
public class ReadData extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name= req.getParameter("name");          //name
		String age1= req.getParameter("age1");
		int age= Integer.parseInt(age1);                //age
		String gender= req.getParameter("gen");         //gen
		String aNo= req.getParameter("aNo");            //aNo
		String address= req.getParameter("address");    //address
		
		
//		System.out.println(name);
//		System.out.println(age);
//		System.out.println(gender);
//		System.out.println(aNo);
//		System.out.println(address);
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("harsh");
		EntityManager em= emf.createEntityManager();
		EntityTransaction et= em.getTransaction();
		
		Person p1= new Person();
//		p1.setId(1);
		p1.setName(name);
		p1.setAge(age);
		p1.setGender(gender);
		
		Aadhar a1= new Aadhar();
//		a1.setaId(1);
		a1.setAddress(address);
		a1.setNumber(aNo);
		
		p1.setAadhar(a1);
		a1.setPerson(p1);
		
		et.begin();
		
		em.persist(p1);
		em.persist(a1);
		
		et.commit();
	}
}
