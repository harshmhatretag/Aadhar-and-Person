package com.hib.project;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FetchAllData {

	public static void main(String[] args) {
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("harsh");
		EntityManager em= emf.createEntityManager();
		EntityTransaction et= em.getTransaction();
		
		Query q1= em.createQuery("select p from Person p");
		
		List<Person> l1= q1.getResultList();
		for(Person p:l1)
		{
			System.out.println(p.getId());
			System.out.println(p.getName());
			System.out.println(p.getAge());
			System.out.println(p.getGender());
			System.out.println("-------------------------");
		}
		
		
		System.out.println("====================================");
		
		
		Query q2= em.createQuery("select a from Aadhar a");
		
		List<Aadhar> l2= q2.getResultList();
		for(Aadhar a:l2)
		{
			System.out.println(a.getAddress());
			System.out.println(a.getNumber());
			System.out.println("-------------------------");
		}
		
	}
}
