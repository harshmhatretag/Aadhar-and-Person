package com.hib.project;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/verify")
public class AddharById extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String id= req.getParameter("personId");
		int pid= Integer.parseInt(id);
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("harsh");
		EntityManager em= emf.createEntityManager();
		
		Person p1= em.find(Person.class, pid);
		
		System.out.println(p1.getId());
		System.out.println(p1.getAge());
		System.out.println(p1.getGender());
		System.out.println(p1.getName());
		
		Aadhar a1= p1.getAadhar();
		
		System.out.println(a1.getaId());
		System.out.println(a1.getAddress());
		System.out.println(a1.getNumber());
	}	
}
